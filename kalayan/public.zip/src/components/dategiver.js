export default function datefunction(num) {
    let retunrvadicdate = ["25 MAAS", "27 Isha"];

    if (num===19) {retunrvadicdate=["27 Ashwin 1946","27 Isha Maas 5126"];}
    if (num===20) {retunrvadicdate=["28 Ashwin 1946","28 Isha Maas 5126"];}
    if (num===21) {retunrvadicdate=["29 Ashwin 1946","29 Isha Maas 5126"];}
    if (num===22) {retunrvadicdate=["30 Ashwin 1946","30 Isha Maas 5126"];}
    if (num===23) {retunrvadicdate=["01 Kartik 1946","01 Urja 5126"];}
    if (num===24) {retunrvadicdate=["2 Kartik 1946","2 Urja 5126"];}
    if (num===25) {retunrvadicdate=["3 Kartik 1946","3 Urja 5126"];}
    if (num===26) {retunrvadicdate=["4 Kartik 1946","4 Urja 5126"];}
    if (num===27) {retunrvadicdate=["5 Kartik 1946","5 Urja 5126"];}
    if (num===28) {retunrvadicdate=["6 Kartik 1946","6 Urja 5126"];}
    if (num===29) {retunrvadicdate=["7 Kartik 1946","7 Urja 5126"];}
    if (num===30) {retunrvadicdate=["8 Kartik 1946","8 Urja 5126"];}
    if (num===31) {retunrvadicdate=["9 Kartik 1946","9 Urja 5126"];}
    if (num===1) {retunrvadicdate=["10 Kartik 1946","10 Urja 5126"];}
    if (num===2) {retunrvadicdate=["11 Kartik 1946","11 Urja 5126"];}
    if (num===3) {retunrvadicdate=["12 Kartik 1946","12 Urja 5126"];}
    if (num===4) {retunrvadicdate=["13 Kartik 1946","13 Urja 5126"];}
    if (num===5) {retunrvadicdate=["14 Kartik 1946","14 Urja 5126"];}
    if (num===6) {retunrvadicdate=["15 Kartik 1946","15 Urja 5126"];}
    return retunrvadicdate;
} 




